# age-and-gender
Determining the gender and age of people from images using dlib model.


